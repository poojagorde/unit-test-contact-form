# UnitTestContactForm

A contact form is a short web-based form published on a website. Any visitor can fill out the form and submit it to send a message to the site owner.

KYForm has created a simple contact form which requires the customers to feed in the minimum details like Name, Email, Contact number,Profession and Message. The form has been created using Angular materials and components. This form can be reused in any simple website for their ContactUs Page. Before releasing it to production, they wanted this form to be tested completely for its functionality.

As a Front-end developer, you are now expected to test the contact form page which is build with Angular components and services.

**Following are the scenarios to be tested:**

AddContactFormComponent:
- Contact Form Component should be created successfully
- Entering valid form details should add the contact details
- Entering invalid form details, the form should not be submitted

AddContactService:
- AddContactService should be successfully created
- Contact List should be displayed on calling getContactList
- New contact should be added on calling addContactDetails

### Note
- Use Jasmine spy for testing Angular components having dependancy and for Angular services which depends on HTTPClient 
- Test cases initially present will fail which has to be fixed by adding the neccessary modules

## Development server

Run `ng serve` for a dev server. Navigate to `http://localhost:4200/`. The app will automatically reload if you change any of the source files.

## Running unit tests

Run `ng test` to execute the unit tests via [Karma](https://karma-runner.github.io).
